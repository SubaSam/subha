export function ActionsPlugin({ children }: { children: React.ReactNode }) {
  return children
}
