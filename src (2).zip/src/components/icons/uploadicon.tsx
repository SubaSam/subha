export const UploadIcon = ({ className }: { className?: string }) => (
   <svg xmlns="http://www.w3.org/2000/svg" id="cloud-arrow-up" className={className} width="40" height="39.147" viewBox="0 0 56.941 39.147">
              <g id="Group_29" data-name="Group 29" transform="translate(0 0)">
                <path id="Path_30" data-name="Path 30" d="M73.632,60.512a1.779,1.779,0,0,1,2.52,0l7.118,7.118a1.782,1.782,0,0,1-2.52,2.52l-4.078-4.082v13.5a1.779,1.779,0,0,1-3.559,0v-13.5l-4.078,4.082a1.782,1.782,0,0,1-2.52-2.52Z" transform="translate(-46.421 -49.316)" fill="#d5d5d5" fill-rule="evenodd"/>
                <path id="Path_31" data-name="Path 31" d="M15.68,28.776A19.68,19.68,0,0,1,28.47,24,18.279,18.279,0,0,1,46.855,40.3a11.47,11.47,0,0,1-1.7,22.851H13.456a13.079,13.079,0,0,1-2.986-25.89A14.966,14.966,0,0,1,15.68,28.776ZM18,31.47c-2.694,2.324-4.1,5.125-4.1,7.317v1.594l-1.584.174a9.535,9.535,0,0,0,1.139,19.032H45.15a7.933,7.933,0,1,0,0-15.854H43.371V41.954a14.649,14.649,0,0,0-14.9-14.4A16.121,16.121,0,0,0,18,31.473Z" transform="translate(0 -24)" fill="#d5d5d5"/>
              </g>
            </svg>
);