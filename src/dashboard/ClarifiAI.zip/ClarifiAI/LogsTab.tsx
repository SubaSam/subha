export function LogsTab(){
return (
    <div>
      This is the Logs tab content.
    </div>
)
}