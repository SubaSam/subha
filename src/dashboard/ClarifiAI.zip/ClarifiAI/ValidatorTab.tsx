import React, { useEffect, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowUp, CircleCheck, CirclePlus, RotateCcw } from "lucide-react";
import { Separator } from "@radix-ui/react-dropdown-menu";
import { ChatIcon} from "@/components/icons/Chaticon";
import { ValidateIcon} from "@/components/icons/Validateicon";

import { Command, CommandEmpty, CommandGroup, CommandItem } from "@/components/ui/command";

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { requirementsData } from "@/dashboard/ClarifiAI/requirementsData";

const getCardStyle = (confidence: number, status: string): string => {
  if (status === "Invalid") return "bg-[#2c1010] text-white";
  
  return "bg-[#132109] text-white";
};

export default function ValidatatorTab({ goTouserstories }: { goTouserstories: () => void }) {
 const flattenRequirements = () => {
    const categories = Object.keys(requirementsData[0]) as (keyof typeof requirementsData[0])[];
    const result = [];
    for (const category of categories) {
      const items = requirementsData[0][category];
      if (Array.isArray(items)) {
        for (const item of items) {
          result.push({
            id: (item as any).requirement_id || (item as any).observation_id,
            description: (item as any).requirement_text || (item as any).observation_text,
            confidence: item.confidence_score,
            status: item.confidence_score > 0.8 ? "Valid" : "Invalid",
            original: (item as any).original_text,
            source: (item as any).source_section,
            page: item.page_number,
            line: item.line_number,
            category: category,
            stakeholders: (item as any).stakeholders || [],
          });
        }
      }
    }
    return result;
  };


  const [requirements, setRequirements] = useState(flattenRequirements());
  const [confidenceThreshold, setConfidenceThreshold] = React.useState(0);
  const [statusFilter, setStatusFilter] = useState("All");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [chatReq, setChatReq] = useState<typeof requirements[0] | null>(null);
  const [chatHistories, setChatHistories] = useState<Record<string, { type: "system" | "user"; text: string }[]>>({});
  const [inputMessage, setInputMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const currentMessages = chatReq ? chatHistories[chatReq.id] ?? [] : [];
  const [searchText, setSearchText] = useState("");
  const [successMessage, setSuccessMessage] = useState<string | null>("Requirements Generated Successfully!");




  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [currentMessages]);

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  const handleSendMessage = () => {
    if (!inputMessage.trim() || !chatReq) return;
    setChatHistories((prev) => {
      const existing = prev[chatReq.id] ?? [];
      return {
        ...prev,
        [chatReq.id]: [...existing, { type: "user", text: inputMessage }],
      };
    });
    setInputMessage("");
  };

  const totalValidators = requirements.length;
  const filteredRequirements = requirements.filter((req) => {
    const meetsConfidence = req.confidence >= confidenceThreshold;
    const meetsStatus = statusFilter === "All" || req.status.toLowerCase() === statusFilter.toLowerCase();
    const meetsId = selectedIds.length === 0 || selectedIds.includes(req.id);
    const meetsSearch =
      searchText.trim() === "" ||
      req.description?.toLowerCase().includes(searchText.toLowerCase()) ||
      req.id.toLowerCase().includes(searchText.toLowerCase());
    return meetsConfidence && meetsStatus && meetsId && meetsSearch;
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const totalPages = Math.ceil(filteredRequirements.length / rowsPerPage);
  const paginated = filteredRequirements.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  const toggleId = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const clearAllFilters = () => {
    setStatusFilter("All");
    setSelectedIds([]);
    setConfidenceThreshold(0);
    setSearchText("");
  };

  const validateRequirements = (id: string) => {
    setRequirements((prev) =>
      prev.map((req) => {
        if (req.id === id) {
          const systemMessages = chatHistories[id]?.filter((msg) => msg.type === "system") || [];
          const latestSystemMessage = systemMessages[systemMessages.length - 1]?.text || req.description;
          return {
            ...req,
            status: "Valid",
            confidence: 1.0,
            description: latestSystemMessage,
          };
        }
        return req;
      })
    );
    setChatReq(null);
    setSuccessMessage(`Validated Successfully for REQ ID – ${id}`);
  };

  return (
    <>
    <div className=" bg-[#f6f6f6] dark:bg-[#2e2D2D] rounded-2xl text-black dark:text-white h-[62vh] overflow-hidden flex flex-col">
    <div className="px-3 py-3  border-b border-gray-700">
    <h1 className="text-md font-semibold">Validate Requirements</h1>
    <p className="text-[12px] text-gray-400">Validate {totalValidators} Requirements</p>
</div>
    
       <div className="flex gap-4 p-2 items-center">
        <Input placeholder="Filter tasks..."   value={searchText}
  onChange={(e) => setSearchText(e.target.value)} className="w-1/4" />
       
          <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              className="border border-dashed border-gray-400 px-4 py-2 rounded-lg flex items-center gap-2 text-black dark:text-white"
            >
              <CirclePlus className="w-4 h-4" /> Validation: {statusFilter}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
            <Command>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup>
                {["All", "Valid", "Invalid"].map((option) => (
                  <CommandItem
                    key={option}
                    value={option}
                    onSelect={(val) => setStatusFilter(val)}
                    className={`cursor-pointer ${
                      statusFilter === option ? "bg-gray-700 text-white" : ""
                    }`}
                  >
                    {option}
                  </CommandItem>
                ))}
              </CommandGroup>
            </Command>
          </PopoverContent>
        </Popover>
           <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              className="border border-dashed border-gray-400 px-4 py-2 rounded-lg flex items-center gap-2 text-black dark:text-white"
            >
              <CirclePlus className="w-4 h-4" /> Req Id
            </Button>
          </PopoverTrigger>
          <PopoverContent  className="w-25 bg-gray-900 border-gray-700 text-white p-4 rounded-lg shadow-xl">
            <ScrollArea className="h-34 w-full pr-2">
              <div className="flex flex-col gap-2">
                {requirements.map((req) => (
                  <label key={req.id} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      id={`checkbox-${req.id}`}
                      checked={selectedIds.includes(req.id)}
                      onCheckedChange={() => toggleId(req.id)}
                    />
                    <span className="text-white font-medium">{req.id}</span>
                  </label>
                ))}
              </div>
              {/* <ScrollBar orientation="vertical" /> */}
            </ScrollArea>
          </PopoverContent>
        </Popover>
    
          <div className="flex items-center gap-4">
          <label className="text-sm font-medium whitespace-nowrap">Confidence</label>
          <div className="flex items-center gap-1">
            <span className="text-sm font-mono px-2 py-1 bg-[#d0d0d0] dark:bg-gray-800 rounded">
              {confidenceThreshold.toFixed(1)}
            </span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={confidenceThreshold}
              onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
              className="w-48 h-2 accent-black dark:accent-white bg-[#d0d0d0] dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
          <Button
    variant="ghost"
    onClick={clearAllFilters}
    className="ml-auto text-sm text-black dark:text-white dark:hover:text-red-800   bg-white dark:bg-black px-3 py-2 hover:text-red-800  "
  ><span><RotateCcw /></span>
    Clear Filters
  </Button>
      </div>

      <ScrollArea className="flex-1 overflow-y-auto px-6 pb-4">
        <div className="grid grid-cols-1 px-6 sm:grid-cols-2 md:grid-cols-3 gap-4 ">
          {paginated.map((req) => (
            <Card style={{ borderRadius: 25 }}
  key={req.id}
  className={`${getCardStyle(req.confidence, req.status)} relative group overflow-visible`}
>
  <CardContent className="p-2 relative z-0">
    <div className="absolute top-2 right-2">
      
      <Badge
  className={`px-2 py-0.5 text-xs rounded-md ${
    req.confidence > 0.5
      ? 'bg-[#0B6058] text-[#5AB4B2]'
      : req.confidence < 0.5
      ? 'bg-[#8E6B74] text-[#83263A]'
      : 'bg-[#86713D] text-[#F7CB9B]'
  }`}
>
  {req.confidence.toFixed(2)}
</Badge>
    </div>
    <div className="mb-2">
      <span className="text-sm font-bold">REQ ID</span>
      <div className="text-sm">{req.id}</div>
    </div>
    <h3 className="font-semibold text-sm mb-1">Description</h3>
    <p className="text-sm mb-3">{req.description}</p>


  </CardContent>
      {/* Hover Overlay */}
      {req.status === "Invalid" &&(
<div className="absolute inset-0 z-10 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ borderRadius: 25 }}>    
  <Button
        variant="secondary"
  className="text-black shadow-md bg-white hover:bg-gray-100"
  onClick={() => {
    setChatReq(req);
    setChatHistories((prev) => {
      if (prev[req.id]) return prev;
      return {
        ...prev,
        [req.id]: [
          { type: "system", text: "Hi how can I help you today?" },
          { type: "user", text: "Hey, I'm having trouble with my account" },
          { type: "system", text: "What seems to be the problem?" }
        ]
      };
    });
  }}
      >
       <span><ChatIcon></ChatIcon> </span>Chat
      </Button>
    </div>
      )}

</Card>

          ))}
        </div>
        <ScrollBar orientation="vertical" />
      </ScrollArea>
 {chatReq && (
<div className="fixed bottom-6 right-6 w-[350px] sm:w-[400px] max-h-[calc(100vh-100px)] rounded-xl bg-[#1c1c1c] border border-gray-700 shadow-xl z-50 overflow-hidden text-white flex flex-col">
    
    {/* Header */}
    <div className="flex items-center justify-between p-3 border-b border-gray-700 bg-[#2a2a2a]">
      <h2 className="text-white font-semibold text-base">Chat</h2>
      <button
        onClick={() => {
          setChatReq(null);
          setInputMessage("");
        }}
        className="text-white text-xl hover:text-red-400"
      >
        –
      </button>
    </div>

    {/* REQ Info */}
    <div className="p-3 border-b border-gray-700 text-sm">
      <div className="flex justify-between mb-1">
        <div>
        <span className="text-white font-semibold">REQ ID - {chatReq.id}</span>
        <span className={`pl-2 text-xs  font-semibold ${chatReq.status === 'Valid' ? 'text-green-400' : 'text-red-400'}`}>
          {chatReq.status}
        </span></div>
        <span><Button className="h-6"onClick={()=>validateRequirements(chatReq.id)}>Validate</Button></span>
      </div>
      <p className="text-white/80 text-xs font-semibold mb-1">Description</p>
      <p className="text-white/60 text-xs leading-snug line-clamp-2">{chatReq.description}</p>
    </div>

    {/* Chat messages */}
    <div className="flex-1 overflow-y-auto p-3 space-y-3 text-sm border-b border-gray-700">
      {currentMessages.map((msg, index) => (
        <div
          key={index}
          className={`px-3 py-2 rounded-md w-fit ${
            msg.type === "user" ? "bg-white text-black ml-auto" : "bg-[#333] text-white"
          }`}
        >
          {msg.text}
        </div>
      ))}
      <div ref={messagesEndRef} />
    </div>

    {/* Input */}
    <div className="p-3 border-t border-gray-700">
      <div className="relative">
        <Input
          placeholder="Type a message..."
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleSendMessage();
          }}
          className="bg-zinc-800 text-white border border-zinc-600  px-4 pr-10 py-2 text-sm"
        />
        <Button
          size="icon"
          onClick={handleSendMessage}
          className="absolute right-1 top-1/2 -translate-y-1/2 rounded-full bg-gray-500 text-black hover:bg-gray-200 w-7 h-7"
        ><ArrowUp />
          {/* <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path d="M2.94 2.94a..." />
          </svg> */}
        </Button>
      </div>
    </div>
  </div>
)}


      
    </div>
    

<div className="flex justify-between items-center h-9 border-b border-gray-700 text-sm bg-[#f6f6f6] dark:bg-black text-black dark:text-white ">
            <div className="text-black dark:text-gray-400 m-1.5">
              {`0 of ${filteredRequirements.length} row(s) selected.`}
            </div>
    
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-black dark:text-white">Rows per page</span>
                <select
                  className="bg-black border border-gray-700 text-white rounded px-2 py-1"
                  value={rowsPerPage}
                  onChange={(e) => {
                    setCurrentPage(1);
                    setRowsPerPage(parseInt(e.target.value));
                  }}
                >
                  {[2, 5, 10, 25].map((val) => (
                    <option key={val} value={val}>{val}</option>
                  ))}
                </select>
              </div>
    
              <div className="text-black dark:text-white">
                Page {currentPage} of {totalPages}
              </div>
    
              <div className="flex items-center gap-1">
                <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&laquo;</button>
                <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&lsaquo;</button>
                <button onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&rsaquo;</button>
                <button onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&raquo;</button>
              </div>
            </div>
          </div>
    
          <div className="flex justify-between gap-2 mt-2">
            <span className="flex flex-row  gap-2 mr-[300px]">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 30.266 30.266">
              <path d="M30.266,15.133A15.133,15.133,0,1,1,15.133,0,15.133,15.133,0,0,1,30.266,15.133ZM22.756,9.4a1.419,1.419,0,0,0-2.043.042l-6.57,8.37-3.959-3.961a1.419,1.419,0,0,0-2.005,2.005l5.005,5.007a1.419,1.419,0,0,0,2.041-.038l7.551-9.439A1.419,1.419,0,0,0,22.758,9.4Z" fill="#24d304" />
            </svg>
            Validator generated Successfully!
          </span><div className="flex gap-2">
            <Button
              className="bg-white dark:bg-[#0D0D0D] text-black dark:text-white border border-gray-500"
              disabled={filteredRequirements.length === 0}
              // onClick={goToClassifier}
            >
              Regenerate Response
            </Button>
            <Button
              className="bg-black text-white dark:bg-[#E5E5E5] dark:text-black"
              disabled={filteredRequirements.length === 0}
              onClick={goTouserstories}
            >
              User Stories
            </Button>
            </div>
          </div>
</>
  );
}