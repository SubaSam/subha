'use client';

import * as React from 'react';
import UploadTab from './UploadTab';
import  ClassifierTab  from './ClassifierTab';
import  ValidatorTab  from './ValidatorTab';
import  UserStoriesTab  from './UserStoriesTab';
import  GherkinTab  from './GherkinTab';
import  TestCasesTab  from './TestCasesTab';
import TraceabilityTab  from './TraceabilityTab';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Check, X } from 'lucide-react';
import type { Requirement } from './UploadTab';

const steps = [
  { value: 'upload', label: '1. Upload' },
  { value: 'classifier', label: '2. Classifier' },
  { value: 'validator', label: '3. Validator' },
  { value: 'user stories', label: '4. User Stories' },
  { value: 'gherkin', label: '5. Gherkin' },
  { value: 'test cases', label: '6. Test Cases' },
  { value: 'traceability', label: '7. Traceability' },
 
];

export function Clarifi() {
  const [activeTab, setActiveTab] = React.useState('upload');
  const [fileTriedToExtract, setFileTriedToExtract] = React.useState(false);

  const [completedSteps, setCompletedSteps] = React.useState<{ [key: string]: boolean }>({
    upload: false,
    classifier: false,
    validator: false,
  });

  const [extractedData, setExtractedData] = React.useState<Requirement[]>([]);
  const [extractionStatus, setExtractionStatus] = React.useState<'idle' | 'success' | 'failed'>('idle');

  const handleUploadComplete = (data: Requirement[]) => {
    setExtractedData(data);

    if (data.length > 0) {
      setExtractionStatus('success');
      setCompletedSteps((prev) => ({ ...prev, upload: true }));
    } else if (fileTriedToExtract) {
      setExtractionStatus('failed');
    }
  };

  const goToClassifier = () => {
    setActiveTab('classifier'); // ✅ only navigates
  };
  const goToValidator = () => {
    setActiveTab('validator'); // ✅ only navigates
  };
  const goTouserstories = () => {
    setActiveTab('validator'); // ✅ only navigates
  };
  const goTogerkin = () => {
    setActiveTab('validator'); // ✅ only navigates
  };
  const goTotestcases = () => {
    setActiveTab('testcases'); // ✅ only navigates
  };
  const goToTraceability = () => {
    setActiveTab('traceability'); // ✅ only navigates
  };
  // const markClassifierComplete = () => {
  //   setCompletedSteps((prev) => ({ ...prev, classifier: true }));
  // };

  const isStepEnabled = (index: number) => {
    if (index === 0) return true;
    const prevStep = steps[index - 1].value;
    return completedSteps[prevStep] === true;
  };

  return (
    <>
    <div className="w-full">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-8 w-full bg-[#2e2D2D] rounded-md h-[6.5vh]">
          {steps.map((step, index) => {
            const isCompleted = completedSteps[step.value];
            // const isDisabled = !isStepEnabled(index);

            const showRed =
              step.value === 'upload' &&
              fileTriedToExtract &&
              extractionStatus === 'failed' &&
              extractedData.length === 0;

            return (
              <TabsTrigger
                key={step.value}
                value={step.value}
                // disabled={isDisabled}
                className={`w-full rounded-md px-2 py-2 text-xs font-medium text-white transition-all flex items-center justify-center gap-2 ${
                  activeTab === step.value ? 'bg-purple-500 shadow' : ''
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border flex items-center justify-center text-[9px] ${
                    showRed
                      ? 'bg-red-500 border-red-500'
                      : isCompleted
                      ? 'bg-green-500 border-green-500'
                      : activeTab === step.value
                      ? 'bg-[#B164FF] border-white'
                      : 'bg-black border-gray-500'
                  }`}
                >
                  {isCompleted && <Check className="w-2 h-2 text-white" />}
                  {showRed && <X className="w-2 h-2 text-white" />}
                </div>
                {step.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value="upload">
          <UploadTab
            onUploadComplete={handleUploadComplete}
            isUploadComplete={completedSteps.upload || false}
            extractedData={extractedData}
            extractionStatus={extractionStatus}
            goToClassifier={goToClassifier}
            onExtractTriggered={() => setFileTriedToExtract(true)}
          />
        </TabsContent>

        <TabsContent value="classifier">
          <ClassifierTab 
           goTovalidator={goToValidator}/>
        </TabsContent>

        <TabsContent value="validator">
          <ValidatorTab 
          goTouserstories={goTouserstories}/>
        </TabsContent>

        <TabsContent value="user stories">
          <UserStoriesTab 
          goTogerkin={goTogerkin}/>
        </TabsContent>

        <TabsContent value="gherkin">
          <GherkinTab
            goTotestcases={goTotestcases}/>
         
        </TabsContent>
        <TabsContent value="test cases">
          <TestCasesTab
          goToTraceability={goToTraceability}
          /></TabsContent>

        <TabsContent value="traceability">
          <TraceabilityTab /></TabsContent>
        
      </Tabs>
    </div>
    </>
  );
}

export default Clarifi;
