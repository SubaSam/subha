/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import React, { useEffect, useRef, useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronsUpDown } from 'lucide-react';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import { RotateCcw, CircleCheck, CirclePlus } from "lucide-react";
import { Separator } from "@radix-ui/react-separator";

export default function ValidatatorTab({ goTovalidator }: { goTovalidator: () => void }) {
  const [requirements, setRequirements] = useState([
    { id: "001", confidence: 1.0, status: "Valid", category: "UI", stakeholder: "Designer", description: "Configure UI settings." },
    { id: "002", confidence: 0.0, status: "Invalid", category: "Backend", stakeholder: "Engineer", description: "Setup server config." },
    { id: "003", confidence: 1.0, status: "Valid", category: "API", stakeholder: "Engineer", description: "Create endpoint for user data." },
    { id: "004", confidence: 1.0, status: "Invalid", category: "UI", stakeholder: "Manager", description: "Improve navigation UX." },
    { id: "005", confidence: 0.5, status: "Valid", category: "UI", stakeholder: "Designer", description: "Configure the NGM GL account numbe internally for GL settlement Allow" },
    { id: "006", confidence: 1.0, status: "Valid",  category: "UI", stakeholder: "Designer",description: "Configure the NGM GL account numbe internally for GL settlement Allow" },
    { id: "007", confidence: 1.0, status: "Valid",  category: "UI", stakeholder: "Designer",description: "Configure the NGM GL account numbe internally for GL settlement Allow" },
  
  ]);

  const [confidenceThreshold, setConfidenceThreshold] = useState(0);
  const [descriptionFilter, setDescriptionFilter] = useState("All");
  const [confidenceFilter, setConfidenceFilter] = useState("All");

  const [categoryFilter, setCategoryFilter] = useState("All");
  const [stakeholderFilter, setStakeholderFilter] = useState("All");

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);


  const filteredRequirements = requirements.filter((req) => {
    // const meetsConfidence = req.confidence >= confidenceThreshold;
    const meetsConfidence =
    req.confidence >= confidenceThreshold &&
    (confidenceFilter === "All" || req.confidence.toFixed(2) === confidenceFilter);

    const meetsDescription = descriptionFilter === "All" || req.description === descriptionFilter;
    const meetsCategory = categoryFilter === "All" || req.category.toLowerCase() === categoryFilter.toLowerCase();
    const meetsStakeholder = stakeholderFilter === "All" || req.stakeholder.toLowerCase() === stakeholderFilter.toLowerCase();  
    const meetsId = selectedIds.length === 0 || selectedIds.includes(req.id);
    
    const meetsSearch =
    searchText.trim() === "" || req.category.toLowerCase().includes(searchText.toLowerCase()) || req.stakeholder
    
    .toLowerCase().includes(searchText.toLowerCase())||
    req.description.toLowerCase().includes(searchText.toLowerCase()) ||
    req.id.toLowerCase().includes(searchText.toLowerCase());
    return meetsConfidence && meetsCategory && meetsStakeholder && meetsId && meetsSearch && meetsDescription;
  }); 

  const totalPages = Math.ceil(filteredRequirements.length / rowsPerPage);
  const paginated = filteredRequirements.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const totalValidators = requirements.length;
  const uniqueCategories = [...new Set(requirements.map((req) => req.category))];
  const uniqueStakeholders = [...new Set(requirements.map((req) => req.stakeholder))];
  const toggleId= (id: string) => {
    setSelectedIds((prev)=>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);  
  }
  const uniqueDescriptions = useMemo(() => {
  const desc = requirements.map((item) => item.description ?? "");
  return [...new Set(desc)].sort();
  }, [requirements]);

  const uniqueConfidenceScores = useMemo(() => {
  const scores = requirements.map((item) => item.confidence?.toFixed(2) ?? "");
  return [...new Set(scores)].sort((a, b) => parseFloat(b) - parseFloat(a));
  }, [requirements]);

  const [open, setOpen] = useState(false);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isStakeholderOpen, setIsStakeholderOpen] = useState(false);
  const [isConfidenceOpen, setIsConfidenceOpen] = useState(false);
  const [isDescriptionOpen, setIsDescriptionOpen] = useState(false);
  const [isCategoryfilterOpen, setCategoryfilterOpen] = useState(false);
  const [isStakeholderFilterOpen, setIsStakeholderFilterOpen] = useState(false);

    useEffect(() => {
      if (showSuccessMessage) {
        const timer = setTimeout(() => setShowSuccessMessage(false), 5000);
        return () => clearTimeout(timer);
      }
    }, [showSuccessMessage]);

  return (
    <>
    <div className="p-2  gap-2 bg-[#f6f6f6] dark:bg-[#181818] text-black dark:text-white rounded-lg">
      <div className=" border-b border-gray-700 px-1 py-1 mt-[-2px]">
          <h1 className="text-[16px] font-semibold ">Classifier List</h1>
          <p className="text-[12px] text-gray-400">Validate {totalValidators} Requirements</p>
      </div>
     
      <div className="flex gap-2 items-center mt-2 ">
        <Input
          placeholder="Filter tasks..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="w-1/4"
        />

        <Popover open={isCategoryOpen} onOpenChange={setIsCategoryOpen}>
          <PopoverTrigger asChild>
            <Button variant="ghost" className="border border-dashed border-gray-400 px-4 py-2 rounded-lg">
              <CirclePlus className="w-4 h-4" /> Category
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
            <Command>
              <CommandGroup>
                {["All", ...uniqueCategories].map((option) => (
                  <CommandItem
                    key={option}
                    onSelect={() => {setCategoryFilter(option); setIsCategoryOpen(false);}}
                    className={categoryFilter === option ? "bg-gray-700 text-white" : ""}
                  >
                    {option}
                  </CommandItem>
                ))}
              </CommandGroup>
            </Command>
          </PopoverContent>
        </Popover>

        <Popover open={isStakeholderOpen} onOpenChange={setIsStakeholderOpen}>
          <PopoverTrigger asChild>
            <Button variant="ghost" className="border border-dashed border-gray-400 px-4 py-2 rounded-lg">
              <CirclePlus className="w-4 h-4" /> Stakeholder
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
            <Command>
              <CommandGroup>
                {["All", ...uniqueStakeholders].map((option) => (
                  <CommandItem
                    key={option}
                    // value = {option}
                    onSelect={() => {setStakeholderFilter(option), setIsStakeholderOpen(false);}}
                    className={stakeholderFilter === option ? "bg-gray-700 text-white" : ""}
                  >
                    {option}
                  </CommandItem>
                ))}
              </CommandGroup>
            </Command>
          </PopoverContent>
        </Popover>

         <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              className="border border-dashed border-gray-400 px-4 py-2 rounded-lg flex items-center gap-2 text-black dark:text-white"
            >
              <CirclePlus className="w-4 h-4" /> Req Id
            </Button>
          </PopoverTrigger>
          <PopoverContent  className="w-25 bg-gray-900 border-gray-700 text-white p-4 rounded-lg shadow-xl">
            <ScrollArea className="h-34 w-full pr-2">
              <div className="flex flex-col gap-2">
                {requirements.map((req) => (
                  <label key={req.id} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      id={`checkbox-${req.id}`}
                      checked={selectedIds.includes(req.id)}
                      onCheckedChange={() => toggleId(req.id)}
                    />
                    <span className="text-white font-medium">{req.id}</span>
                  </label>
                ))}
              </div>
              <ScrollBar orientation="vertical" />
            </ScrollArea>
          </PopoverContent>
        </Popover>

        <div className="flex items-center gap-4">
          <label className="text-sm font-medium">Confidence</label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={confidenceThreshold}
            onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
            className="w-48 h-2 accent-black dark:accent-white bg-[#d0d0d0] dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-sm font-mono px-2 py-1 bg-[#d0d0d0] dark:bg-gray-800 rounded">
            {confidenceThreshold.toFixed(1)}
          </span>
        </div>

        <Button
          onClick={() => {
            // setStatusFilter("All");
            setCategoryFilter("All");
            setStakeholderFilter("All");
            setSearchText("");
            setConfidenceThreshold(0);
            setDescriptionFilter("All");
            setConfidenceFilter("All");
            setSelectedIds([]);
          }}
          className="ml-auto text-sm text-black dark:text-white  bg-white dark:bg-black px-3 py-2 "
        >
          <RotateCcw className="mr-1" /> Clear Filters
        </Button>
      </div>

      <div >    
      <ScrollArea className="overflow-y-auto h-[255px] w-full mt-2 ">
      <Table >

      {/* className="w-full h-[10px] mt-[-8px] border-separate border-spacing-y-2 rounded-xl overflow-y-auto scrollbar-thin"> */}
        <TableHeader className="bg-white text-black  dark:bg-[#111111] tdark:text-white">
  <TableRow>
    <TableHead className="text-left">
      <Popover>
        <PopoverTrigger asChild>
          <div className="flex items-center gap-1 ">
            REQ ID
            <ChevronsUpDown className="w-4 h-4 text-white mt-0.5" />
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-48 bg-gray-900 border-gray-700 text-white p-4 rounded-lg shadow-xl">
          <ScrollArea className="h-100 w-full pr-2">
            <div className="flex flex-col gap-2">
              {requirements.map((req) => (
                <label key={req.id} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    id={`checkbox-${req.id}`}
                    checked={selectedIds.includes(req.id)}
                    onCheckedChange={() => toggleId(req.id)}
                  />
                  <span className="text-white font-medium">{req.id}</span>
                </label>
              ))}
            </div>
            <ScrollBar orientation="vertical" />
          </ScrollArea>
        </PopoverContent>
      </Popover>
    </TableHead>

    <TableHead className="text-left">
      <Popover open={isCategoryfilterOpen} onOpenChange={setCategoryfilterOpen}>
        <PopoverTrigger asChild>
          {/* Wrap only the icon */}
        <div className="flex items-center gap-1 ">
          Category
          <ChevronsUpDown className="w-4 h-4 text-white mt-0.5" />
        </div>
        </PopoverTrigger>
        <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
          <Command>
            <CommandGroup>
              {["All", ...uniqueCategories].map((option) => (
                <CommandItem
                  key={option}
                  onSelect={() => {setCategoryFilter(option), setCategoryfilterOpen(false);}}
                  className={categoryFilter === option ? "bg-gray-700 text-white" : ""}
                >
                  {option}
                </CommandItem>
              ))}
            </CommandGroup>
          </Command>
        </PopoverContent>
      </Popover> 
    </TableHead>

    <TableHead className="text-left">
  <Popover open={isConfidenceOpen} onOpenChange={setIsConfidenceOpen}>
    <PopoverTrigger asChild>
      <div className="flex items-center gap-1 ">
        Confidence
        <ChevronsUpDown className="w-4 h-4 text-white mt-0.5" />
      </div>
    </PopoverTrigger>
    <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
      <Command>
        <CommandGroup>
          {["All", ...uniqueConfidenceScores].map((option) => (
            <CommandItem
              key={option}
              onSelect={() => {setConfidenceFilter(option), setIsConfidenceOpen(false);}}
              className={confidenceFilter === option ? "bg-gray-700 text-white" : ""}
            >
              {option}
            </CommandItem>
          ))}
        </CommandGroup>
      </Command>
    </PopoverContent>
  </Popover>
</TableHead>


    <TableHead className="text-left">
      <Popover open={isStakeholderFilterOpen} onOpenChange={setIsStakeholderFilterOpen}>
        <PopoverTrigger asChild>
          <div className="flex items-center gap-1 ">
            Stakeholder
            <ChevronsUpDown className="w-4 h-4 text-white mt-0.5" />
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
          <Command>
            <CommandGroup>
              {["All", ...uniqueStakeholders].map((option) => (
                <CommandItem
                  key={option}
                  onSelect={() => {setStakeholderFilter(option), setIsStakeholderFilterOpen(false)}}
                  className={stakeholderFilter === option ? "bg-gray-700 text-white" : ""}
                >
                  {option}
                </CommandItem>
              ))}
            </CommandGroup>
          </Command>
        </PopoverContent>
      </Popover>
    </TableHead>

    <TableHead className="text-left">
  <Popover open={isDescriptionOpen} onOpenChange={setIsDescriptionOpen}>
    <PopoverTrigger asChild>
      <div className="flex items-center gap-1 ">
        Description
        <ChevronsUpDown className="w-4 h-4 text-white mt-0.5" />
      </div>
    </PopoverTrigger>
    <PopoverContent className="w-48 p-0 bg-gray-900 border-gray-700 text-white">
      <Command>
        <CommandGroup>
          {["All", ...uniqueDescriptions].map((option) => (
            <CommandItem
              key={option}
              onSelect={() => {setDescriptionFilter(option), setIsDescriptionOpen(false)}}
              className={descriptionFilter === option ? "bg-gray-700 text-white" : ""}
            >
              {option}
            </CommandItem>
          ))}
        </CommandGroup>
      </Command>
    </PopoverContent>
  </Popover>
</TableHead>

  </TableRow>
</TableHeader>
 {/* <div className="pr-1 mt-2 space-y-2 h-[215px] overflow-y-auto scrollbar-thin border border-[#4D4B4B] bg-[#26262675] rounded-lg"> */}
        {/* <ScrollArea className="overflow-y-auto w-full h-[200px]"> */}
        <TableBody > 
          {paginated.map((req, index) => (
            <TableRow key={req.id} 
            className={`text-black dark:text-white text-sm rounded-lg  overflow-hidden ${
      index % 2 === 0 ? 'bg-[#d0d0d0] dark:bg-[#181818]' : 'bg-[#ececec]	dark:bg-[#2a2a2a]'
          }`}>
              <TableCell className="px-6 ">{req.id}</TableCell>
              <TableCell className="px-4 ">{req.category}</TableCell>
              <TableCell className="px-2">
                <Badge className={`p-1 text-xs rounded-md ${
                        req.confidence > 0.5 ? 'bg-[#0B6058] text-[#5AB4B2]' : 
                        req.confidence < 0.5 ? 'bg-[#8E6B74] text-[#83263A]' :
                        'bg-[#86713D] text-[#F7CB9B]'}`}>
                  {req.confidence.toFixed(2)}
                </Badge>
              </TableCell>            
              <TableCell className="px-2">{req.stakeholder}</TableCell>
              <TableCell className="whitespace-normal break-words max-w-xs">{req.description}</TableCell>
            </TableRow>
          ))}
        </TableBody>
        {/* <ScrollBar orientation="vertical"></ScrollBar>
        </ScrollArea> */}
        {/* </div> */}
      </Table>
      <ScrollBar orientation="vertical"></ScrollBar>
      </ScrollArea>
      </div>
      
</div>

      <div className="flex justify-between items-center h-9 border-b border-gray-700 text-sm bg-[#f6f6f6] dark:bg-black text-black dark:text-white ">
        <div className="text-black dark:text-gray-400 m-1.5">
          {`0 of ${filteredRequirements.length} row(s) selected.`}
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-black dark:text-white">Rows per page</span>
            <select
              className="bg-black border border-gray-700 text-white rounded px-2 py-1"
              value={rowsPerPage}
              onChange={(e) => {
                setCurrentPage(1);
                setRowsPerPage(parseInt(e.target.value));
              }}
            >
              {[2, 5, 10, 25].map((val) => (
                <option key={val} value={val}>{val}</option>
              ))}
            </select>
          </div>

          <div className="text-black dark:text-white">
            Page {currentPage} of {totalPages}
          </div>

          <div className="flex items-center gap-1">
            <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&laquo;</button>
            <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&lsaquo;</button>
            <button onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&rsaquo;</button>
            <button onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages} className="px-2 py-1 rounded border border-gray-600 disabled:opacity-50">&raquo;</button>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-2">
        <span className="flex flex-row  gap-2 mr-[430px]">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 30.266 30.266">
          <path d="M30.266,15.133A15.133,15.133,0,1,1,15.133,0,15.133,15.133,0,0,1,30.266,15.133ZM22.756,9.4a1.419,1.419,0,0,0-2.043.042l-6.57,8.37-3.959-3.961a1.419,1.419,0,0,0-2.005,2.005l5.005,5.007a1.419,1.419,0,0,0,2.041-.038l7.551-9.439A1.419,1.419,0,0,0,22.758,9.4Z" fill="#24d304" />
        </svg>
        Classifier list generated Successfully!
      </span>
        <Button
          className="bg-white dark:bg-[#0D0D0D] text-black dark:text-white border border-gray-400"
          disabled={filteredRequirements.length === 0}
          // onClick={goToClassifier}
        >
          Regenerate Response
        </Button>
        <Button
          className="bg-black text-white dark:bg-[#E5E5E5] dark:text-black"
          disabled={filteredRequirements.length === 0}
          // onClick={goTovalidator}
        >
          Validate
        </Button>
      </div>
    
    </>
  );
}
