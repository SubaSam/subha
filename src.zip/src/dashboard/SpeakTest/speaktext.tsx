'use client';

import React, { useState } from 'react';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Card,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import VoiceTranscriber from './recorder';
import axios from 'axios';
import Sitevalidator from './sitevalidator';

interface TabsDemoProps {
  isSidebarCollapsed?: boolean;
}

export function TabsDemo({ isSidebarCollapsed }: TabsDemoProps) {
  const [transcribedText, setTranscribedText] = useState('');
  const [speakIframeUrl, setSpeakIframeUrl] = useState<string | null>(null);
  const [speakLoading, setSpeakLoading] = useState(false);
  const [speakResponse, setSpeakResponse] = useState<{
    output?: string;
    error?: string;
    status?: string;
  } | null>(null);

  const [siteTranscribedText, setSiteTranscribedText] = useState('');
  const [siteIframeUrl, setSiteIframeUrl] = useState<string | null>(null);
  const [siteLoading, setSiteLoading] = useState(false);
  const [siteResponse, setSiteResponse] = useState<{
    output?: string;
    error?: string;
    status?: string;
  } | null>(null);

  const handleProceed = async () => {
    if (!transcribedText.trim()) return;

    // setSpeakResponse(null);
    setSpeakLoading(true);
    try {
      const response = await axios.post('http://localhost:8000/run_voice_task/', {
        input_text: transcribedText,
        sender_id: 'user1234',
      });

      setSpeakResponse(response.data);
    } catch (err) {
      console.error('Request failed:', err);
      setSpeakIframeUrl(null);
    } finally {
      setSpeakLoading(false);
    }
  };

  const handleSiteValidator = async () => {
    if (!siteTranscribedText.trim()) return;
    setSiteLoading(true);
    try {
      const response = await axios.post('http://localhost:8000/run_text_task/', {
        input_text: siteTranscribedText,
        sender_id: 'user1234',
      });

      setSiteResponse(response.data);
    } catch (err) {
      console.error('Request failed:', err);
      setSiteIframeUrl(null);
    } finally {
      setSiteLoading(false);
    }
  };

  const dynamicwidth = isSidebarCollapsed ? 'w-[93vw]' : 'w-[77.6vw]';

  return (
    <div className="flex w-full max-w-sm flex-col gap-6">
      <Tabs defaultValue="Speaktest">
        <TabsList className="h-[7vh] w-[23vw] bg-[#2E2D2D] rounded-xl">
          <TabsTrigger value="Speaktest" className="flex items-center">
            <span style={{ marginLeft: '8px' }}>Speak Test</span>
          </TabsTrigger>
          <TabsTrigger value="SiteValidator" className="flex items-center">
            <span style={{ marginLeft: '10px' }}>Site Validator</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="Speaktest">
          <Card className={`bg-[#181818] ${dynamicwidth} mt-2 transition-all duration-300 h-[12rem]`}>
            <CardHeader>
              <CardTitle className="text-white" style={{ marginTop: '-14px', marginBottom: '5px', fontFamily: 'fantasy', fontSize: '13px' }}>
                Let's get started
              </CardTitle>
              <VoiceTranscriber transcribedText={transcribedText} setTranscribedText={setTranscribedText} />
            </CardHeader>

            <CardFooter className="flex flex-col items-start gap-2 mt-[-11px]">
              <Button onClick={handleProceed} disabled={speakLoading || !transcribedText.trim()}>
                {speakLoading ? 'Loading...' : 'Proceed'}
              </Button>

              {speakResponse?.output && (
                <div className="bg-gray-900 text-white p-4 rounded-md w-full mt-4 max-h-[300px] overflow-auto text-sm">
                  <h3 className="font-semibold mb-2">Automation Output:</h3>
                  <pre className="whitespace-pre-wrap">
                    {typeof speakResponse.output === 'object'
                      ? JSON.stringify(speakResponse.output, null, 2)
                      : speakResponse.output
                          .replace(/\\n/g, '\n')
                          .replace(/},\s*/g, '},\n\n')
                          .replace(/,/g, ',\n')}
                  </pre>
                </div>
              )}
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="SiteValidator">
          <Card className={`bg-[#181818] ${dynamicwidth} mt-2 transition-all duration-300 h-[12rem]`}>
            <CardHeader>
              <CardTitle style={{ marginTop: '-14px', marginBottom: '5px', fontFamily: 'fantasy', fontSize: '13px' }}>
                Enter Task Instructions
              </CardTitle>
              <Sitevalidator siteTranscribedText={siteTranscribedText} setSiteTranscribedText={setSiteTranscribedText} />
            </CardHeader>

            <CardFooter className="flex flex-col items-start gap-2 mt-[-11px]">
              <Button onClick={handleSiteValidator} disabled={siteLoading || !siteTranscribedText.trim()}>
                {siteLoading ? 'Loading...' : 'Proceed'}
              </Button>

              {siteResponse?.output && (
                <div className="bg-gray-900 text-white p-4 rounded-md w-full mt-4 max-h-[300px] overflow-auto text-sm">
                  <h3 className="font-semibold mb-2">Automation Output:</h3>
                  <pre className="whitespace-pre-wrap">
                    {typeof siteResponse.output === 'object'
                      ? JSON.stringify(siteResponse.output, null, 2)
                      : siteResponse.output
                          .replace(/\\n/g, '\n')
                          .replace(/},\s*/g, '},\n\n')
                          .replace(/,/g, ',\n')}
                  </pre>
                </div>
              )}
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default TabsDemo;
