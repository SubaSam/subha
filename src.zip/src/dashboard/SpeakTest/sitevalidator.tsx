import React, { useState } from 'react';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

import { Textarea } from '@/components/ui/textarea';

type SitevalidatorProps = {
  siteTranscribedText: string;
  setSiteTranscribedText: (text: string) => void;
};

const Sitevalidator: React.FC<SitevalidatorProps> = ({ siteTranscribedText, setSiteTranscribedText }) => {

    // const [siteTranscribedText, setSiteTranscribedText] = useState('');
    return (

    
<Textarea
            className="w-full h-[16vh] "
            rows={6}
            placeholder="Enter your instructions here..."
            value={siteTranscribedText}
            onChange={(e) => setSiteTranscribedText(e.target.value)}
          /> )
}

export default Sitevalidator;