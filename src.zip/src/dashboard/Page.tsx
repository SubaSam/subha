import { AppSidebar } from "@/components/app-sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import LandingPage from "@/components/LandingPage"
// import { Sensei } from "@/components/sensei"
import { slugify } from "@/lib/slugify"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Separator } from "@/components/ui/separator"
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import React, { useEffect } from "react"
import Clarifi from "./ClarifiAI/clarifi"
import TabsDemo from "./SpeakTest/speaktext"

export default function Page() {
  const [activePage, setActivePage] = React.useState("Test Sage");
  
 useEffect(() => {
  const pages = [
    "ClarifAI",
    "CodeSensei",
    "CodeSpectre",
    "CodeGenie",
    "VelocityLens",
    "DevXcelerateGenerator",
    "DevXcelerateConverter",
    "TestSage",
    "Settings",
  ];

  const slug = location.pathname.split("/").pop()?.toLowerCase() || "";

  const slugToName = Object.fromEntries(
    pages.map((name) => [slugify(name), name])
  );

  setActivePage(slugToName[slug] || "");
}, [location]);

   const renderContent = () => {
    switch (activePage) {
      case "ClarifAI":
        return <Clarifi/>
      case "CodeSensei":
        return <div />
      case "CodeSpectre":
        return <div>This is Code Spectre</div>
      case "CodeGenie":
        return <div>This is Code Genie</div>
      case "VelocityLens":
        return <div>This is Velocity Lens</div>
      case "DevXcelerateGenerator":
        return <div>This is DevXcelerate Generator</div>
      case "DevXcelerateConverter":
        return <div>This is DevXcelerate Converter</div>
      case "TestSage":
        return <TabsDemo />;
      default:
        return <div>Select a project</div>
    }
  }
  return (
    <SidebarProvider>
      <AppSidebar setActivePage={setActivePage} activePage={activePage} />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12">
          <div className="flex items-center gap-2 px-4 w-full">
            <SidebarTrigger className="-ml-1" />
            <Separator
              orientation="vertical"
              className="mr-2 data-[orientation=vertical]:h-4"
            />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink href="#">
                    {activePage}
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  {/* <BreadcrumbPage>Data Fetching</BreadcrumbPage> */}
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
            <div className="ms-auto"><ModeToggle /></div>
            
          </div>
        </header>
        <div className="flex flex-1 flex-col gap-4 p-4 pt-0">
          
          <div className="min-h-[100vh] flex-1 rounded-xl md:min-h-min" >
          {renderContent()}</div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
