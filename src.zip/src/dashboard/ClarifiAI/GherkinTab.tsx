export function GherkinTab(){
    return (
    <div>
      This is the Gherkin tab content.
    </div>
)
}