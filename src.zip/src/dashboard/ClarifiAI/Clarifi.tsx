'use client';

import UploadTab  from './UploadTab';
import {ClassifierTab} from './ClassifierTab';
import {ValidatorTab} from './ValidatorTab';
import {UserStoriesTab} from './UserStoriesTab';
import {GherkinTab} from './GherkinTab';
import {TestCasesTab} from './TestCasesTab';
import {TraceabilityTab} from './TraceabilityTab';
import {LogsTab} from './LogsTab';



import * as React from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

const steps = [
  { value: 'upload', label: '1. Upload' },
  { value: 'classifier', label: '2. Classifier' },
  { value: 'validator', label: '3. Validator' },
  { value: 'user stories', label: '4. User Stories' },
  { value: 'gherkin', label: '5. Gherkin' },
  { value: 'test cases', label: '6. Test Cases' },
  { value: 'tracebility', label: '7. Traceability' },
  { value: 'logs', label: '8. Logs' },
];

export function Clarifi() {
  const [activeTab, setActiveTab] = React.useState('upload');

  return (
    <div className="w-full">
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        >
        <div className='bg-red'> 
        <TabsList
          className="flex flex-wrap justify-between bg-[#2e2D2D] rounded-md  h-[7vh] w-full  "
        >
          {steps.map((step) => (
            <TabsTrigger
              key={step.value}
              value={step.value}
              className={`whitespace-nowrap rounded-md px-4 py-2 text-white font-medium text-sm transition-all flex items-center gap-[2px] ${
                activeTab === step.value ? 'bg-purple-500 shadow' : 'bg-[#2e2D2D]'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full border-1  ${
                  activeTab === step.value ? 'border-white bg-[#B164FF] ' : 'border-gray-500 bg-black'
                }`}
              />
              {step.label}
            </TabsTrigger>
          ))}
        </TabsList>
          </div> 
        <div><TabsContent value="upload"><UploadTab /></TabsContent></div>
        <TabsContent value="classifier"><ClassifierTab /></TabsContent>
        <TabsContent value="validator"><ValidatorTab /></TabsContent>
        <TabsContent value="user stories"><UserStoriesTab /></TabsContent>
        <TabsContent value="gherkin"><GherkinTab /></TabsContent>
        <TabsContent value="test cases"><TestCasesTab /></TabsContent>
        <TabsContent value="tracebility"><TraceabilityTab /></TabsContent>
        <TabsContent value="logs"><LogsTab /></TabsContent>

      </Tabs>
    </div>
  );
}

export default Clarifi;
