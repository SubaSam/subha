export function TraceabilityTab(){
    return (
    <div>
      This is the traceability tab content.
    </div>
)
}