export function ValidatorTab(){
    return (
    <div>
      This is the Validator tab content.
    </div>
)
}