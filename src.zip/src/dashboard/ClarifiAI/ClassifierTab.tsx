export function ClassifierTab(){
    return (
    <div>
      This is the Classifier tab content.
    </div>
)
}