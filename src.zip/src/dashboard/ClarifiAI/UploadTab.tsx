'use client';

import React, { useState, useRef } from 'react';
import { UploadCloud, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const UploadTab = () => {
  const [file, setFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const removeFile = () => {
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatSize = (bytes: number) => {
    return `${(bytes / 1024).toFixed(1)}Kb`;
  };

  const handleExtract = () => {
    if (file) {
      alert(`Extracting requirements from: ${file.name}`);
      // Place extraction logic here
    }
  };

  return (
    <div className="p-4 space-y-4 bg-[#1e1e1e] rounded-lg shadow w-full max-w-3xl mx-auto text-white">
      <h2 className="text-lg font-semibold">Upload Files</h2>

      {/* Upload Box */}
      <div
        className="border border-dashed border-gray-500 rounded-md p-6 flex flex-col items-center justify-center cursor-pointer hover:border-purple-500 transition relative"
        onClick={() => fileInputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <UploadCloud className="w-8 h-8 text-gray-400 mb-2" />
        <p className="text-sm text-gray-400">Click here or Drag and drop file here</p>
        <p className="text-xs text-gray-500 mt-1">Limit 200MB per file - .CSV</p>
        <input
          type="file"
          accept=".csv"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />
      </div>

      {/* File Preview */}
      {file && (
        <div className="flex items-center justify-between bg-[#2e2d2d] px-4 py-2 rounded-md">
          <span className="text-sm">
            {file.name} <span className="text-gray-400 ml-2">{formatSize(file.size)}</span>
          </span>
          <button onClick={removeFile}>
            <X className="w-4 h-4 text-gray-400 hover:text-red-400" />
          </button>
        </div>
      )}

      {/* Extract Button */}
      <Button
        className="bg-[#B164FF] text-black hover:bg-[#9a4edc]"
        onClick={handleExtract}
        disabled={!file}
      >
        Extract Requirements
      </Button>
    </div>
  );
};

export default UploadTab;
