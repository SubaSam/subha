import {
  Folder,
  Forward,
  MoreHorizontal,
  Trash2,
  type LucideIcon,
} from "lucide-react"

// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuSeparator,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu"
import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar"
import { cn } from "@/lib/utils"
// interface NavProjectsProps {
//   projects: {
//     name: string
//     icon: React.ComponentType<React.SVGProps<SVGSVGElement>>
//   }[]
//   onSelect: (name: string) => void,
//   activePage: string
// }
type NavProjectsProps = {
  projects: { name: string
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>> 
  }[]
  onSelect: (page: string) => void;
  activePage: string;
};
export function NavProjects({
  projects,
  onSelect,
  activePage
}: NavProjectsProps) {
  //const { isMobile } = useSidebar()
console.log("recevived onselect:", onSelect);
  return (
    <SidebarGroup className="group-data-[collapsible=icon]:hidden">
      <SidebarGroupLabel>Modules</SidebarGroupLabel>
      <SidebarMenu>
        {projects.map((item) => (
          <SidebarMenuItem key={item.name} >
            <SidebarMenuButton onClick={() => onSelect(item.name)}
            
              className={cn("flex items-center gap-3",
             item.name === activePage
              ? "text-purple-600 font-semibold hover:text-purple-600"
              : "text-muted-foreground hover:bg-accent"
          )}>
              
                 <span className="shrink-0">
    <item.icon
      className={cn(
        "!w-[30px] !h-[30px]", // Force override
        activePage === item.name ? "text-purple-600" : "text-muted-foreground"
      )}
    />
  </span>
                <span>{item.name}</span>
              
            </SidebarMenuButton>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </SidebarGroup>
    
  )
}
